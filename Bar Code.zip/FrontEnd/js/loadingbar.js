(function($){
  $('.trigger').click(function(){
    $('#ajaxloader1, .outer, .inner, .barlittle, .pointcircle, .bar, #loadpulse div, #shadowloader span, .loadingtext span').toggleClass('stop');
  });
})(jQuery);