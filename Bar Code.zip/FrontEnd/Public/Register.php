<?php
session_start();
include_once "header/header.php";
if ($_SESSION['Auth']==1) {
?>
<body>

		<div class="wrapper">
			<div class="inner">
				<form action="../../Backend/Private/RegisterProcess.php" method="POST">
					<h3>Registeration Form</h3>
					<p>Welcome From Our........</p>
					<label class="form-group" >
						<input type="text" name="Name" class="form-control"  required="" autocomplete="off">
						<span>Your Name</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="text" name="Phone" class="form-control"  autocomplete="off" required>
						<span for="">Your Phone</span>
						<span class="border"></span>
					</label>
					<button name="Register">Register<i class="zmdi zmdi-arrow-right"></i></button>

				</form>
			</div>
		</div>

	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>

<?php
}
else{
	header("Location: ../../index.php");
}

?>