<?php
session_start();
if ($_Session['$user_code']=true) {
  # code...
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="../css/loadingbar.css">
   <script src="../js/loadingbar.js"></script>
</head>
<body>
<a class="trigger" style="display:none" href="#">Play/Stop Animations</a>

<div id="ajaxloader1"></div>

<div id="ajaxloader2">
  <div class="outer"></div>
  <div class="inner"></div>
</div>

<div id="ajaxloader3">
  <div class="outer"></div>
  <div class="inner"></div>
</div>

<div id="ajaxbar1">
  <div id="block1" class="barlittle"></div>
  <div id="block2" class="barlittle"></div>
  <div id="block3" class="barlittle"></div>
  <div id="block4" class="barlittle"></div>
  <div id="block5" class="barlittle"></div>
</div>


<div id="loadpulse">
  <div class="segment">
    <div id="layer1" class="ball"></div>
    <div id="layer7" class="pulse"></div>
  </div>
  <div class="segment">
    <div id="layer2" class="ball"></div>
    <div id="layer8" class="pulse"></div>
  </div>
  <div class="segment">
    <div id="layer3" class="ball"></div>
    <div id="layer9" class="pulse"></div>
  </div>
  <div class="segment">
    <div id="layer4" class="ball"></div>
    <div id="layer10" class="pulse"></div>
  </div>
  <div class="segment">
    <div id="layer5" class="ball"></div>
    <div id="layer11" class="pulse"></div>
  </div>
</div>

<div id="shadowloader">
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</div>

<h1 class="loadingtext">
  <span>R</span>
  <span>U</span>
  <span>N</span>
  <span>N</span>
  <span>i</span>
  <span>n</span>
  <span>g</span>
</h1>

</body>
</html>
<script>
    setTimeout("window.location.href = \'Register.php';", 2000);
</script>

<?php
}else{
  header("Location: ../../index.php");
}
?>