<?php
ob_start();
session_start();
if ($_SESSION['Auth']==1) {
?>
<!DOCTYPE html>
<html>
<head>
  <title>Success</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<img src="../images/Complete.gif" class="img-fluid" alt="Responsive image"><br/>
</body>
</html>
 <?php
  $_SESSION['Auth']=false; 
 }
 $_SESSION['Auth']=false; 
 ?>

