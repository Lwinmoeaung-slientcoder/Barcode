
<?php
require_once "dbconfig.php";
date_default_timezone_set('Asia/Rangoon');
// array for JSON response

$json = file_get_contents('php://input');
$obj = json_decode($json);
$mei = $obj->{'Error'};
$data= $obj->{'IMEI'};



$t=strtotime("now");
$s = date("m/d/Y h:i:s A T",$t);
    
      
$sql = "INSERT INTO `ErrorTable` ( `IMEI`, `Error`, `Time`) VALUES ( '$mei', '$data', '$s');";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


?>
