
<?php
require_once "dbconfig.php";

// array for JSON response
$response = array();
 $response["TicketNumber"] = array();

$name = $_REQUEST['Name'];
$phone= $_REQUEST['Phone'];
$data = $_REQUEST['code'];

//Data fROM Android
$gettingdata = "SELECT TicketType_ID from TicketNumber where TicketID = '$data'";
$res = mysqli_query($conn,$gettingdata);
 $row = mysqli_fetch_array($res);
           //Getting ID from TicketNumber with code
        $db_type=$row["TicketType_ID"];
    if(is_null($db_type)) {
         $products = array();
         $products["ID"] = "CODE NOT FOUND";
        array_push($response["TicketNumber"], $products);
        // push single product into final response array
        $response["Code Not Found"] = 2;
        echo json_encode($response);
    }else{
         $sql = "INSERT INTO TicketData (`TicketNumber_ID`, `Name`, `Phone`) 
 VALUES ( '$db_type', '$name', '$phone');";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
          
      }
      



?>
