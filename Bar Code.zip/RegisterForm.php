
<?php
require_once "dbconfig.php";

// array for JSON response
$response = array();
 $response["TicketNumber"] = array();
$json = file_get_contents('php://input');
$obj = json_decode($json);
$name = $obj->{'code1'};
$phone= $obj->{'code2'};
$data = $obj->{'code'};
//Data fROM Android
$gettingdata = "SELECT ID from TicketNumber where TicketID = '$data'";
$res = mysqli_query($conn,$gettingdata);
 $row = mysqli_fetch_array($res);
           //Getting ID from TicketNumber with code
        $db_type=$row["ID"];
       
      $sql = "UPDATE `TicketData` SET `Name`='$name', `Phone`='$phone' WHERE `TicketNumber_ID`='$db_type';
";
if ($conn->query($sql) === TRUE) {
  //  echo "New record created successfully";
  $product = array();
          $product["Message"] = "Success";
          
          array_push($response["TicketNumber"], $product);
        // push single product into final response array
        $response["success"] = 1;
        echo json_encode($response);
} else {
      $product = array();
          $product["Message"] = "Failed";
          
          array_push($response["TicketNumber"], $product);
        // push single product into final response array
        $response["success"] = 0;
        echo json_encode($response);
   // echo "Error: " . $sql . "<br>" . $conn->error;
}   
    

          
      
      



?>
