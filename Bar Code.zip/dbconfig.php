<?php

$conn=mysqli_connect("localhost","id9629381_testingappforward","Androidphp","id9629381_wcs");
if(!$conn){
  die('Query Failed'.mysqli_error($conn));

}else{
//echo "<script>alert('Success')</script>";
}

?>
