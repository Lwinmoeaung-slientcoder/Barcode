<?php
require_once "dbconfig.php";

// array for JSON response
$response = array();
 $response["TicketNumber"] = array();
$data = $_REQUEST['code'];

//Data fROM Android
$gettingdata = "SELECT ID,TicketType_ID from TicketNumber where TicketID = '$data'";
$res = mysqli_query($conn,$gettingdata);

   
      $qr_code=$_REQUEST['code'];
      $row = mysqli_fetch_array($res);
          $db_ida=$row["ID"];   //Getting ID from TicketNumber with code
        $db_type=$row["TicketType_ID"];
    if(is_null($db_type)) {
         $products = array();
         $products["ID"] = "CODE NOT FOUND";
        array_push($response["TicketNumber"], $products);
        // push single product into final response array
        $response["Code Not Found"] = 2;
        echo json_encode($response);
    }else{
          $gettype = "Select Type,Price from TicketType where ID='$db_type'";
      $re = mysqli_query($conn,$gettype);
      if(mysqli_num_rows($re)>0){
          $r = mysqli_fetch_array($re);
              $t= $r["Type"];
              $p = $r["Price"];
          
      }
     
    $query="SELECT ID,Name , Phone , Enter_Count FROM TicketData where TicketNumber_ID = '$db_ida'";// get all products from products table
$result=mysqli_query($conn,$query);


    // looping through all results
    // products node

   
   $rows = mysqli_fetch_array($result);
        // temp user array
        $db_id=$rows["ID"];
        $db_name=$rows["Name"];
        $db_phone=$rows["Phone"];
        $db_entry = $rows["Enter_Count"];
     
        if(is_null($db_entry)){
            $db_entry=0;
        }
        $entry_code= $db_entry+1;
       
        if( $entry_code == 1){
            
        $sql = "UPDATE `TicketData` SET `Enter_Count` = '$entry_code' WHERE `TicketNumber_ID`= '$db_ida';";

        }else{
             $sql = "UPDATE `TicketData` SET `Enter_Count` = '$entry_code' WHERE `TicketNumber_ID`= '$db_ida';";

        }
if ($conn->query($sql) === TRUE) {
   // echo "New record created successfully";
} else {
//    echo "Error: " . $sql . "<br>" . $conn->error;
}
        
        
          
    
  
  // code...
          $product = array();
          $product["ID"] = $db_id;
          $product["NAME"] = $db_name;
          $product["PHONE"] = $db_phone;
          $product["Type"] = $t;
          $product["Price"]= $p;
          $product["EntryCode"]= $db_entry;
          array_push($response["TicketNumber"], $product);
        // push single product into final response array
        $response["success"] = 1;
        echo json_encode($response);

     
    }  
      
    
      


?>
