<?php
ob_start();
session_start();
require_once "../../dbconfig.php";
 $_SESSION['user_code']=$_REQUEST['code'];
  if (isset($_POST['submit'])) {
      $sql="SELECT * FROM TicketNumber";
      $result=mysqli_query($conn,$sql);
          while ($row=mysqli_fetch_assoc($result)) {
            //$barcode_id=$row['ID'];
            $barcode_code=$row['BarcodeID'];
            $_SESSION['ticket_id']=$row['ID'];
            if ($_SESSION['user_code']!=$barcode_code) {
                $_SESSION['Auth']=false;
               echo "<script>alert('Sorry!!Please Check Your Barcode Again')</script>";
                header("Location: ../../index.php");
                //break;
                    }
            else{
              
             $_SESSION['Auth']=1;
            header("Location: ../../FrontEnd/Public/");
               break;

            }
          }
        }
          ob_end_flush();
?>