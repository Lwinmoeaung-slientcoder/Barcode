<?php
 ob_start();
session_start();
require_once "../../dbconfig.php";
if ($_SESSION['Auth']==1) {
  # code...
if (isset($_POST['Register'])) {
  # code...
  $username=mysqli_real_escape_string($conn,$_POST['Name']);
    $_SESSION['successuser']=$username;
  $phone=mysqli_real_escape_string($conn,$_POST['Phone']);
  $ticketnumber_id=(int)$_SESSION['ticket_id'];
echo $ticketnumber_id;
  $sql="INSERT INTO TicketData (TicketNumber_ID,Name,Phone) VALUES ('$ticketnumber_id','$username','$phone')";
  $result=mysqli_query($conn,$sql);
  if ($result) {
      header("Location: ../../FrontEnd/Public/Success.php");
  unset($username);
  unset($phone);
  ob_end_flush();
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
  
  
}
}else{
  header("Location: ../../index.php");
}

?>