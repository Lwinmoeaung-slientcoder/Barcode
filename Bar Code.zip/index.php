<!DOCTYPE html>
<html lang="en">
<head>
	<title>BarCode Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="FrontEnd/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="FrontEnd/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="FrontEnd/vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="FrontEnd/vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="FrontEnd/vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="FrontEnd/css/util.css">
	<link rel="stylesheet" type="text/css" href="FrontEnd/css/main.css">
	<script src="FrontEnd/vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="FrontEnd/vendor/bootstrap/js/popper.js"></script>
	<script src="FrontEnd/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="FrontEnd/vendor/select2/select2.min.js"></script>
	<script src="FrontEnd/vendor/tilt/tilt.jquery.min.js"></script>
	<script src="FrontEnd/js/main.js"></script>
</head>
<body>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="FrontEnd/images/img-01.png" alt="IMG">
				</div>
					<form class="login100-form validate-form" action="Backend/Private/Checkingcode.php" method="POST">
					<span class="login100-form-title">
						User Login
					</span>
					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="Password" name="code" placeholder="Type Your Barcode">
						<span class="focus-input100"></span>
					</div>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit">
							Login
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>
<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>